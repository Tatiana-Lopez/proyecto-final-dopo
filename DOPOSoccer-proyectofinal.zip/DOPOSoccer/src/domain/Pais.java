package domain;

public enum Pais {
    CANADA("Canada"),
    COLOMBIA("Colombia"),
    BRASIL("Brasil"),
    JAPON("Japon"),
    ALEMANIA("Alemania");

    private final String nombre;

    Pais(String nombre){
        this.nombre = nombre;
    }

    public String getNombre(){
        return nombre;
    }

    @Override
    public String toString(){
        return nombre;
    }
}
