package domain;

public class PoderFuego extends Poder{

    public PoderFuego(){
        super("Fuego", 5);
    }

    @Override
    public void aplicarA(Jugador oponente){
        oponente.ralentizar(getDuracionSegundos());
    }
}

