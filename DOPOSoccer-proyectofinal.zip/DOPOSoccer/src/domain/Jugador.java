package domain;

public class Jugador {
    private static final double SEGUNDOS_ATURDIMIENTO = 3.0;
    private static final double SEGUNDOS_INMUNIDAD = 2.0;
    private static final double SEGUNDOS_PATADA = 0.3;
    private static final double ANCHO_REFERENCIA = 40;
    private static final double ANCHO_BASE = 64;
    private static final double ALTO_BASE = 96;
    private static final double ESCALA_REDUCIDO = 0.5;
    private static final double ESCALA_LENTO = 0.5;
    private static final double PIXELES_POR_VELOCIDAD = 75;
    private static final double SALTO_BASE = 380;
    private static final double SALTO_POR_NIVEL = 60;
    private static final double ALCANCE_PATADA = 40;
    private static final double FUERZA_BASE = 250;
    private static final double FUERZA_POR_NIVEL = 80;
    private static final double IMPULSO_VERTICAL = -380;
    private static final double DISTANCIA_INICIAL = 170;

    private final String nombre;
    private final Personaje personaje;
    private final Lado lado;
    private final BarraDePoder barraDePoder;
    private int goles;
    private double segundosAturdido;
    private double segundosInmune;
    private double segundosReducido;
    private double segundosConfundido;
    private double segundosLento;
    private double segundosPatada;
    private double segundosPoderActivo;
    private Poder poderActivo;

    private double x;
    private double y;
    private double velocidadY;

    public Jugador(String nombre, Personaje personaje, Lado lado){
        this.nombre = nombre;
        this.personaje = personaje;
        this.lado = lado;
        this.barraDePoder = new BarraDePoder();
        this.goles = 0;
        this.segundosAturdido = 0;
        this.segundosInmune = 0;
        this.segundosReducido = 0;
        this.segundosConfundido = 0;
        this.segundosLento = 0;
        this.segundosPatada = 0;
        this.segundosPoderActivo = 0;
        this.poderActivo = null;
        colocarEnInicio();
    }

    public void colocarEnInicio(){
        x = (lado == Lado.IZQUIERDO) ? DISTANCIA_INICIAL : Cancha.ANCHO - DISTANCIA_INICIAL;
        y = Cancha.ALTO;
        velocidadY = 0;
        segundosPatada = 0;
    }

    public void desplazar(double dx){
        double mitad = getAncho() / 2;
        x = Math.max(mitad, Math.min(Cancha.ANCHO - mitad, x + dx));
    }

    public void mover(int direccion, double segundos){
        if (estaAturdido()){
            return;
        }
        if (estaConfundido()){
            direccion = -direccion;
        }
        double escala = estaLento() ? ESCALA_LENTO : 1;
        x += direccion * personaje.getVelocidad() * PIXELES_POR_VELOCIDAD * escala * segundos;
        double mitad = getAncho() / 2;
        x = Math.max(mitad, Math.min(Cancha.ANCHO - mitad, x));
    }

    public void saltar(){
        if (estaAturdido() || !estaEnSuelo()){
            return;
        }
        velocidadY = -(SALTO_BASE + SALTO_POR_NIVEL * personaje.getSalto());
    }

    public boolean puedePatear(){
        return !estaAturdido() && segundosPatada <= 0;
    }

    public boolean patear(Balon balon){
        if (!puedePatear()){
            return false;
        }
        segundosPatada = SEGUNDOS_PATADA;
        int sentido = (lado == Lado.IZQUIERDO) ? 1 : -1;
        double dx = balon.getX() - x;
        if (dx * sentido < 0){
            return false;
        }
        double dy = balon.getY() - (y - getAlto() / 2);
        double distancia = Math.sqrt(dx * dx + dy * dy);
        if (distancia > ALCANCE_PATADA + Balon.RADIO + getAncho() / 2){
            return false;
        }
        double fuerza = FUERZA_BASE + FUERZA_POR_NIVEL * personaje.getFuerza();
        balon.patear(sentido * fuerza, IMPULSO_VERTICAL);
        return true;
    }

    public boolean alcanza(Jugador otro){
        if (!puedePatear()){
            return false;
        }
        int sentido = (lado == Lado.IZQUIERDO) ? 1 : -1;
        double dx = (otro.x - x) * sentido;
        double alcanceX = ALCANCE_PATADA + (getAncho() + otro.getAncho()) / 2;
        double dy = Math.abs((y - getAlto() / 2) - (otro.y - otro.getAlto() / 2));
        double alcanceY = (getAlto() + otro.getAlto()) / 2;
        return dx >= 0 && dx <= alcanceX && dy <= alcanceY;
    }

    public void actualizarFisica(double segundos){
        velocidadY += Cancha.GRAVEDAD * segundos;
        y += velocidadY * segundos;
        if (y >= Cancha.ALTO){
            y = Cancha.ALTO;
            velocidadY = 0;
        }
    }

    public void avanzarTiempo(double segundos){
        boolean estabaAturdido = segundosAturdido > 0;
        segundosAturdido = Math.max(0, segundosAturdido - segundos);
        if (estabaAturdido && segundosAturdido == 0){
            segundosInmune = SEGUNDOS_INMUNIDAD;
        }
        segundosInmune = Math.max(0, segundosInmune - segundos);
        segundosReducido = Math.max(0, segundosReducido - segundos);
        segundosConfundido = Math.max(0, segundosConfundido - segundos);
        segundosLento = Math.max(0, segundosLento - segundos);
        segundosPatada = Math.max(0, segundosPatada - segundos);
        if (poderActivo != null){
            segundosPoderActivo = Math.max(0, segundosPoderActivo - segundos);
            if (segundosPoderActivo == 0){
                poderActivo = null;
            }
        }
    }

    public boolean usarPoder(Jugador oponente){
        if (!barraDePoder.estaLlena()){
            return false;
        }
        Poder poder = personaje.getPoder();
        poder.aplicarA(oponente);
        poderActivo = poder;
        segundosPoderActivo = poder.getDuracionSegundos();
        barraDePoder.vaciar();
        return true;
    }

    public void anotarGol(){
        goles++;
    }

    public void aturdir(){
        aturdir(SEGUNDOS_ATURDIMIENTO);
    }

    public void aturdir(double segundos){
        if (segundosInmune > 0 || segundosAturdido > 0){
            return;
        }
        segundosAturdido = segundos;
    }

    public void reducir(double segundos){
        segundosReducido = segundos;
    }

    public void confundir(double segundos){
        segundosConfundido = segundos;
    }

    public void ralentizar(double segundos){
        segundosLento = segundos;
    }

    public boolean estaAturdido(){
        return segundosAturdido > 0;
    }

    public boolean estaReducido(){
        return segundosReducido > 0;
    }

    public boolean estaConfundido(){
        return segundosConfundido > 0;
    }

    public boolean estaLento(){
        return segundosLento > 0;
    }

    public boolean estaPateando(){
        return segundosPatada > 0;
    }

    public double getProgresoPatada(){
        if (segundosPatada <= 0){
            return 0;
        }
        return 1 - segundosPatada / SEGUNDOS_PATADA;
    }

    public boolean estaEnSuelo(){
        return y >= Cancha.ALTO;
    }

    public double getAncho(){
        return estaReducido() ? ANCHO_BASE * ESCALA_REDUCIDO : ANCHO_BASE;
    }

    public double getAlto(){
        return estaReducido() ? ALTO_BASE * ESCALA_REDUCIDO : ALTO_BASE;
    }

    public double getEscala(){
        return getAncho() / ANCHO_REFERENCIA;
    }

    public double getRadioCabeza(){
        return 24 * getEscala();
    }

    public double getCentroCabezaY(){
        return y - getAlto() + 21 * getEscala();
    }

    public double getRadioPies(){
        return 15 * getEscala();
    }

    public double getCentroPiesY(){
        return y - 14 * getEscala();
    }

    public String getNombre(){
        return nombre;
    }

    public Personaje getPersonaje(){
        return personaje;
    }

    public Lado getLado(){
        return lado;
    }

    public BarraDePoder getBarraDePoder(){
        return barraDePoder;
    }

    public int getGoles(){
        return goles;
    }

    public Poder getPoderActivo(){
        return poderActivo;
    }

    public double getSegundosPoderActivo(){
        return segundosPoderActivo;
    }

    public double getX(){
        return x;
    }

    public double getY(){
        return y;
    }
}