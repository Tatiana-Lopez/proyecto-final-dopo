package domain;

public abstract class Partido {
    private static final double RECARGA_POR_SEGUNDO = 10;
    private static final double VELOCIDAD_CHOQUE = 380;
    private static final double SEGUNDOS_CELEBRACION = 1.5;

    private final Cancha cancha;
    private final Jugador jugador1;
    private final Jugador jugador2;
    private double segundosJugados;
    private double acumuladorRecarga;
    private double segundosCelebracion;
    private boolean pausado;
    private boolean terminado;
    private Jugador ganador;
    private Jugador ultimoAnotador;

    public Partido(Jugador jugador1, Jugador jugador2) throws ExceptionDOPOSoccer{
        if (jugador1.getLado() != Lado.IZQUIERDO || jugador2.getLado() != Lado.DERECHO){
            throw new ExceptionDOPOSoccer(ExceptionDOPOSoccer.LADOS_INVALIDOS);
        }
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.cancha = new Cancha();
        this.segundosJugados = 0;
        this.acumuladorRecarga = 0;
        this.segundosCelebracion = 0;
        this.pausado = false;
        this.terminado = false;
        this.ganador = null;
        this.ultimoAnotador = null;
    }

    public void actualizar(double segundos){
        if (!estaActivo()){
            return;
        }
        if (segundosCelebracion > 0){
            segundosCelebracion -= segundos;
            if (segundosCelebracion <= 0){
                segundosCelebracion = 0;
                reiniciarPosiciones();
            }
            return;
        }
        segundosJugados += segundos;
        recargarBarras(segundos);
        actualizarJugador(jugador1, segundos);
        actualizarJugador(jugador2, segundos);
        separarJugadores();
        Lado lado = cancha.actualizar(segundos);
        if (lado != null){
            registrarGol(lado);
        }
        verificarTiempo();
    }

    private void actualizarJugador(Jugador jugador, double segundos){
        jugador.actualizarFisica(segundos);
        jugador.avanzarTiempo(segundos);
        chocarConBalon(jugador);
    }

    private void separarJugadores(){
        double minimo = (jugador1.getAncho() + jugador2.getAncho()) / 2;
        double dx = jugador2.getX() - jugador1.getX();
        double dy = Math.abs(jugador1.getY() - jugador2.getY());
        double alto = Math.min(jugador1.getAlto(), jugador2.getAlto());
        if (Math.abs(dx) < minimo && dy < alto){
            double empuje = (minimo - Math.abs(dx)) / 2;
            double signo = (dx >= 0) ? 1 : -1;
            jugador1.desplazar(-signo * empuje);
            jugador2.desplazar(signo * empuje);
        }
    }

    private void recargarBarras(double segundos){
        acumuladorRecarga += RECARGA_POR_SEGUNDO * segundos;
        int cantidad = (int) acumuladorRecarga;
        if (cantidad > 0){
            acumuladorRecarga -= cantidad;
            jugador1.getBarraDePoder().recargar(cantidad);
            jugador2.getBarraDePoder().recargar(cantidad);
        }
    }

    private void chocarConBalon(Jugador jugador){
        chocarCirculo(jugador.getX(), jugador.getCentroCabezaY(), jugador.getRadioCabeza());
        chocarCirculo(jugador.getX(), jugador.getCentroPiesY(), jugador.getRadioPies());
    }

    private void chocarCirculo(double cx, double cy, double radio){
        Balon balon = cancha.getBalon();
        double dx = balon.getX() - cx;
        double dy = balon.getY() - cy;
        double distancia = Math.sqrt(dx * dx + dy * dy);
        if (distancia < Balon.RADIO + radio && distancia > 0){
            balon.patear(dx / distancia * VELOCIDAD_CHOQUE, dy / distancia * VELOCIDAD_CHOQUE);
        }
    }

    private void registrarGol(Lado ladoDelArco){
        Jugador dueno = (ladoDelArco == Lado.IZQUIERDO) ? jugador1 : jugador2;
        Jugador anotador = getOponente(dueno);
        anotador.anotarGol();
        ultimoAnotador = anotador;
        segundosCelebracion = SEGUNDOS_CELEBRACION;
        alMarcar(anotador, dueno);
    }

    private void reiniciarPosiciones(){
        jugador1.colocarEnInicio();
        jugador2.colocarEnInicio();
        cancha.reiniciarBalon();
    }

    private boolean puedeActuar(){
        return estaActivo() && segundosCelebracion == 0;
    }

    public void mover(Jugador jugador, int direccion, double segundos){
        if (puedeActuar()){
            jugador.mover(direccion, segundos);
        }
    }

    public void saltar(Jugador jugador){
        if (puedeActuar()){
            jugador.saltar();
        }
    }

    public void patear(Jugador jugador){
        if (!puedeActuar() || !jugador.puedePatear()){
            return;
        }
        Jugador oponente = getOponente(jugador);
        boolean alcanzaRival = jugador.alcanza(oponente);
        boolean golpeoBalon = jugador.patear(cancha.getBalon());
        if (alcanzaRival && golpeoBalon){
            oponente.aturdir();
        }
    }

    public void prepararPoder(Jugador jugador){
        if (puedeActuar() && !jugador.estaAturdido()){
            jugador.usarPoder(getOponente(jugador));
        }
    }

    public void pausar(){
        pausado = true;
    }

    public void reanudar(){
        pausado = false;
    }

    protected void terminar(Jugador ganador){
        this.ganador = ganador;
        this.terminado = true;
    }

    protected abstract void alMarcar(Jugador anotador, Jugador rival);

    public abstract String getTextoModo();

    protected void verificarTiempo(){
    }

    public Jugador getOponente(Jugador jugador){
        return (jugador == jugador1) ? jugador2 : jugador1;
    }

    public boolean estaActivo(){
        return !pausado && !terminado;
    }

    public boolean estaCelebrando(){
        return segundosCelebracion > 0;
    }

    public boolean estaPausado(){
        return pausado;
    }

    public boolean estaTerminado(){
        return terminado;
    }

    public Jugador getGanador(){
        return ganador;
    }

    public Jugador getUltimoAnotador(){
        return ultimoAnotador;
    }

    public double getSegundosJugados(){
        return segundosJugados;
    }

    public Cancha getCancha(){
        return cancha;
    }

    public Jugador getJugador1(){
        return jugador1;
    }

    public Jugador getJugador2(){
        return jugador2;
    }
}