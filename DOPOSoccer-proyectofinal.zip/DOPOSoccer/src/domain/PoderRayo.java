package domain;

public class PoderRayo extends Poder{

    public PoderRayo(){
        super("Rayo", 2);
    }

    @Override
    public void aplicarA(Jugador oponente){
        oponente.aturdir(getDuracionSegundos());
        oponente.getBarraDePoder().vaciar();
    }
}

