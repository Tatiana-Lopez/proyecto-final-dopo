package presentation;
import domain.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.Random;

public class PanelCancha extends JPanel {
    
    private static final int ALTO_MARCADOR = 100;
    private static final int ALTO_PASTO = 20;
    private static final int ANCHO = (int) Cancha.ANCHO;
    private static final int ALTO_CANCHA = (int) Cancha.ALTO;
    private static final int ALTO_TOTAL = ALTO_MARCADOR + ALTO_CANCHA + ALTO_PASTO;
    private static final int RETARDO_MS = 16;
    private static final int MAXIMO_BARRA = 100;
    private static final int FIN_TRIBUNA = 200;
    private static final int INICIO_VALLAS = 205;
    private static final int FIN_VALLAS = 255;
    private static final Color COLOR_1 = new Color(220, 40, 40);
    private static final Color COLOR_2 = new Color(40, 80, 220);
    private static final Color BOTA_1 = new Color(250, 200, 30);
    private static final Color BOTA_2 = new Color(235, 235, 235);
    private static final Color COLOR_SHORT = new Color(35, 35, 45);
    private static final Color COLOR_MEDIA = new Color(240, 240, 240);
    private static final Color[] PIELES = {
        new Color(255, 224, 189), new Color(198, 134, 66), new Color(141, 85, 36),
        new Color(255, 224, 180), new Color(255, 205, 170)
    };
    private static final Color[] PELOS = {
        new Color(214, 170, 80), new Color(60, 35, 20), new Color(20, 15, 15),
        new Color(25, 20, 20), new Color(150, 70, 35)
    };

    private final DOPOSoccerGUI ventana;
    private final Timer temporizador;
    private final BufferedImage fondo;
    private DOPOSoccer juego;
    private long ultimoInstante;
    private double anguloBalon;

    public PanelCancha(DOPOSoccerGUI ventana){
        this.ventana = ventana;
        this.fondo = crearFondo();
        this.anguloBalon = 0;
        setPreferredSize(new Dimension(ANCHO, ALTO_TOTAL));
        setFocusable(true);
        temporizador = new Timer(RETARDO_MS, e -> avanzar());
        addKeyListener(new KeyAdapter(){
            @Override
            public void keyPressed(KeyEvent e){
                procesarTecla(e, true);
            }

            @Override
            public void keyReleased(KeyEvent e){
                procesarTecla(e, false);
            }
        });
    }

    public void iniciar(DOPOSoccer juego){
        this.juego = juego;
        ultimoInstante = System.nanoTime();
        temporizador.start();
        SwingUtilities.invokeLater(() -> requestFocusInWindow());
    }

    public void detener(){
        temporizador.stop();
    }

    private void avanzar(){
        long ahora = System.nanoTime();
        double segundos = Math.min((ahora - ultimoInstante) / 1e9, 0.05);
        ultimoInstante = ahora;
        juego.actualizar(segundos);
        Partido partido = juego.getPartido();
        if (partido.estaActivo()){
            anguloBalon += partido.getCancha().getBalon().getVelocidadX() * segundos / Balon.RADIO;
        }
        repaint();
    }

    private void procesarTecla(KeyEvent e, boolean presionada){
        if (juego == null){
            return;
        }
        teclasJugador1(juego.getControlador1(), e.getKeyCode(), presionada);
        teclasJugador2(juego.getControlador2(), e, presionada);
        if (presionada){
            teclasGenerales(e.getKeyCode());
        }
    }

    private void teclasJugador1(ControladorJugador c, int tecla, boolean presionada){
        switch (tecla){
            case KeyEvent.VK_A:
                c.setIzquierda(presionada);
                break;
            case KeyEvent.VK_D:
                c.setDerecha(presionada);
                break;
            case KeyEvent.VK_W:
                c.setSaltar(presionada);
                break;
            case KeyEvent.VK_S:
                c.setPatear(presionada);
                break;
            case KeyEvent.VK_Q:
                if (presionada){
                    c.pedirPoder();
                }
                break;
            default:
                break;
        }
    }

    private void teclasJugador2(ControladorJugador c, KeyEvent e, boolean presionada){
        switch (e.getKeyCode()){
            case KeyEvent.VK_LEFT:
                c.setIzquierda(presionada);
                break;
            case KeyEvent.VK_RIGHT:
                c.setDerecha(presionada);
                break;
            case KeyEvent.VK_UP:
                c.setSaltar(presionada);
                break;
            case KeyEvent.VK_DOWN:
                c.setPatear(presionada);
                break;
            case KeyEvent.VK_CONTROL:
                if (presionada && e.getKeyLocation() == KeyEvent.KEY_LOCATION_RIGHT){
                    c.pedirPoder();
                }
                break;
            default:
                break;
        }
    }

    private void teclasGenerales(int tecla){
        if (tecla == KeyEvent.VK_P){
            alternarPausa();
        } else if (tecla == KeyEvent.VK_ENTER){
            continuar();
        } else if (tecla == KeyEvent.VK_ESCAPE){
            ventana.mostrarMenu();
        }
    }

    private void alternarPausa(){
        Partido partido = juego.getPartido();
        if (partido.estaTerminado()){
            return;
        }
        if (partido.estaPausado()){
            juego.reanudar();
        } else {
            juego.pausar();
        }
    }

    private void continuar(){
        if (!juego.getPartido().estaTerminado()){
            return;
        }
        try {
            if (!juego.siguienteRonda()){
                ventana.mostrarMenu();
            }
        } catch (ExceptionDOPOSoccer ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ventana.mostrarMenu();
        }
    }

    private Color oscurecer(Color c, double factor){
        return new Color((int) (c.getRed() * factor), (int) (c.getGreen() * factor), (int) (c.getBlue() * factor));
    }

    private BufferedImage crearFondo(){
        BufferedImage imagen = new BufferedImage(ANCHO, ALTO_CANCHA + ALTO_PASTO, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = imagen.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        dibujarPasto(g);
        dibujarTribuna(g);
        dibujarFocos(g);
        dibujarVallas(g);
        dibujarTunel(g);
        g.dispose();
        return imagen;
    }

    private void dibujarTribuna(Graphics2D g){
        g.setPaint(new GradientPaint(0, 0, new Color(20, 20, 35), 0, FIN_TRIBUNA, new Color(70, 60, 70)));
        g.fillRect(0, 0, ANCHO, FIN_TRIBUNA + 10);
        Color[] camisetas = {
            new Color(210, 40, 40), new Color(240, 240, 240), new Color(60, 90, 200), new Color(240, 200, 60),
            new Color(240, 240, 240), new Color(210, 40, 40), new Color(60, 170, 90), new Color(230, 130, 40)
        };
        Color[] pieles = {
            new Color(255, 220, 177), new Color(224, 172, 105), new Color(198, 134, 66), new Color(141, 85, 36)
        };
        Random azar = new Random(7);
        int fila = 0;
        for (int y = 6; y < FIN_TRIBUNA - 4; y += 11){
            double brillo = 0.5 + 0.5 * y / FIN_TRIBUNA;
            int desfase = (fila % 2 == 0) ? 0 : 6;
            for (int x = -6 + desfase; x < ANCHO; x += 12){
                g.setColor(oscurecer(camisetas[azar.nextInt(camisetas.length)], brillo));
                g.fillOval(x, y + 5, 11, 9);
                g.setColor(oscurecer(pieles[azar.nextInt(pieles.length)], brillo));
                g.fillOval(x + 2, y, 7, 7);
            }
            fila++;
        }
    }

    private void dibujarFocos(Graphics2D g){
        int[] focos = {120, 450, 780};
        for (int fx : focos){
            Path2D.Double cono = new Path2D.Double();
            cono.moveTo(fx - 10, 0);
            cono.lineTo(fx + 10, 0);
            cono.lineTo(fx + 110, FIN_VALLAS);
            cono.lineTo(fx - 110, FIN_VALLAS);
            cono.closePath();
            g.setPaint(new GradientPaint(0, 0, new Color(255, 255, 230, 120), 0, FIN_VALLAS,
                    new Color(255, 255, 230, 0)));
            g.fill(cono);
        }
    }

    private void dibujarVallas(Graphics2D g){
        int cantidad = 5;
        int ancho = ANCHO / cantidad;
        g.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 20));
        FontMetrics medidas = g.getFontMetrics();
        String texto = "DOPOSOCCER";
        for (int i = 0; i < cantidad; i++){
            g.setColor(new Color(25, 40, 95));
            g.fillRect(i * ancho + 2, INICIO_VALLAS, ancho - 4, FIN_VALLAS - INICIO_VALLAS);
            g.setColor(new Color(245, 200, 30));
            g.fillRect(i * ancho + 2, INICIO_VALLAS, ancho - 4, 3);
            g.setColor(Color.WHITE);
            g.drawString(texto, i * ancho + (ancho - medidas.stringWidth(texto)) / 2, INICIO_VALLAS + 33);
        }
        g.setColor(new Color(0, 0, 0, 130));
        g.fillRect(0, FIN_VALLAS, ANCHO, 5);
    }

    private void dibujarTunel(Graphics2D g){
        g.setColor(new Color(150, 150, 160));
        g.fillRect(405, 160, 90, FIN_VALLAS - 160);
        g.setColor(new Color(15, 15, 22));
        g.fillRect(413, 168, 74, FIN_VALLAS - 168);
        g.setColor(new Color(190, 40, 40));
        g.fillRect(420, FIN_VALLAS - 12, 60, 8);
        g.setColor(new Color(110, 110, 120));
        g.fillRect(405, 160, 90, 5);
    }

    private void dibujarPasto(Graphics2D g){
        int inferior = ALTO_CANCHA + ALTO_PASTO;
        int franja = 75;
        for (int i = 0; i * franja < ANCHO; i++){
            g.setColor(i % 2 == 0 ? new Color(40, 135, 50) : new Color(48, 150, 58));
            g.fillRect(i * franja, FIN_VALLAS, franja, inferior - FIN_VALLAS);
        }
        g.setPaint(new GradientPaint(0, FIN_VALLAS, new Color(0, 0, 0, 90), 0, FIN_VALLAS + 30,
                new Color(0, 0, 0, 0)));
        g.fillRect(0, FIN_VALLAS, ANCHO, 30);

        int arriba = FIN_VALLAS + 12;
        int abajo = inferior - 4;
        int centroY = (arriba + abajo) / 2;
        g.setColor(new Color(255, 255, 255, 210));
        g.setStroke(new BasicStroke(3));
        g.drawRect(4, arriba, ANCHO - 8, abajo - arriba);
        g.drawLine(ANCHO / 2, arriba, ANCHO / 2, abajo);
        g.drawOval(ANCHO / 2 - 55, centroY - 55, 110, 110);
        g.fillOval(ANCHO / 2 - 4, centroY - 4, 8, 8);
        g.drawRect(4, centroY - 70, 160, 140);
        g.drawRect(4, centroY - 35, 70, 70);
        g.drawRect(ANCHO - 164, centroY - 70, 160, 140);
        g.drawRect(ANCHO - 74, centroY - 35, 70, 70);
        g.setStroke(new BasicStroke(1));
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        if (juego == null || juego.getPartido() == null){
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Partido partido = juego.getPartido();

        dibujarMarcador(g2, partido);

        g2.translate(0, ALTO_MARCADOR);
        dibujarCancha(g2, partido.getCancha());
        dibujarJugador(g2, partido.getJugador1(), COLOR_1, BOTA_1);
        dibujarJugador(g2, partido.getJugador2(), COLOR_2, BOTA_2);
        dibujarBalon(g2, partido.getCancha().getBalon());
        g2.translate(0, -ALTO_MARCADOR);

        dibujarMensajes(g2, partido);
        g2.dispose();
    }

    private void dibujarCancha(Graphics2D g2, Cancha cancha){
        g2.drawImage(fondo, 0, 0, null);
        dibujarArco(g2, cancha.getArcoIzquierdo());
        dibujarArco(g2, cancha.getArcoDerecho());
    }

    private void dibujarArco(Graphics2D g2, Arco arco){
        boolean izquierdo = arco.getLado() == Lado.IZQUIERDO;
        int x = (int) arco.getXMinimo();
        int y = (int) arco.getYTravesano();
        int ancho = (int) (arco.getXMaximo() - arco.getXMinimo());
        int alto = ALTO_CANCHA - y;
        int xFrente = izquierdo ? x + ancho : x;
        int xFondo = izquierdo ? x : x + ancho;

        g2.setColor(new Color(255, 255, 255, 40));
        g2.fillRect(x, y, ancho, alto);

        g2.setColor(new Color(255, 255, 255, 140));
        g2.setStroke(new BasicStroke(1));
        for (int i = 0; i <= ancho; i += 9){
            g2.drawLine(x + i, y, x + i, y + alto);
        }
        for (int j = 0; j <= alto; j += 9){
            g2.drawLine(x, y + j, x + ancho, y + j);
        }

        g2.setColor(new Color(175, 175, 175));
        g2.setStroke(new BasicStroke(4));
        g2.drawLine(xFondo, y, xFondo, y + alto);

        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(7));
        g2.drawLine(x, y, x + ancho, y);
        g2.drawLine(xFrente, y, xFrente, y + alto);
        g2.setColor(new Color(245, 200, 30));
        g2.setStroke(new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f,
                new float[]{8f, 8f}, 0f));
        g2.drawLine(xFrente, y, xFrente, y + alto);
        g2.setStroke(new BasicStroke(1));
    }

    private double anguloPierna(double progreso){
        if (progreso <= 0){
            return 0;
        }
        if (progreso < 0.3){
            return -40 * (progreso / 0.3);
        }
        double q = (progreso - 0.3) / 0.7;
        return -40 * (1 - q) + 80 * Math.sin(q * Math.PI);
    }

    private void dibujarPierna(Graphics2D g2, double cx, double cadera, double largo, double escala,
                               int sentido, double gradosAdelante, Color bota){
        AffineTransform original = g2.getTransform();
        g2.rotate(sentido * Math.toRadians(gradosAdelante), cx, cadera);
        g2.setColor(COLOR_MEDIA);
        g2.setStroke(new BasicStroke((float) (6 * escala), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.draw(new Line2D.Double(cx, cadera, cx, cadera + largo - 5 * escala));
        g2.setStroke(new BasicStroke(1));
        double anchoBota = 19 * escala;
        double altoBota = 10 * escala;
        double xBota = (sentido == 1) ? cx - 5 * escala : cx - anchoBota + 5 * escala;
        double yBota = cadera + largo - altoBota;
        RoundRectangle2D.Double forma = new RoundRectangle2D.Double(xBota, yBota, anchoBota, altoBota,
                7 * escala, 7 * escala);
        g2.setColor(bota);
        g2.fill(forma);
        g2.setColor(new Color(30, 30, 30));
        g2.fill(new RoundRectangle2D.Double(xBota, yBota + altoBota - 3 * escala, anchoBota, 3 * escala,
                2 * escala, 2 * escala));
        g2.setStroke(new BasicStroke(1.2f));
        g2.draw(forma);
        g2.setColor(new Color(255, 255, 255, 170));
        double xBrillo = (sentido == 1) ? xBota + anchoBota - 7 * escala : xBota + 2 * escala;
        g2.fill(new Ellipse2D.Double(xBrillo, yBota + 2 * escala, 5 * escala, 3 * escala));
        g2.setStroke(new BasicStroke(1));
        g2.setTransform(original);
    }

    private void dibujarJugador(Graphics2D g2, Jugador jugador, Color camiseta, Color bota){
        double escala = jugador.getAncho() / 40.0;
        double alto = jugador.getAlto();
        double cx = jugador.getX();
        double pies = jugador.getY();
        double arriba = pies - alto;
        int sentido = (jugador.getLado() == Lado.IZQUIERDO) ? 1 : -1;
        int indice = jugador.getPersonaje().getPais().ordinal();
        Color piel = PIELES[indice % PIELES.length];
        Color pelo = PELOS[indice % PELOS.length];

        double anchoCabeza = 48 * escala;
        double altoCabeza = 42 * escala;
        double yCabeza = arriba;
        double yTorso = arriba + 38 * escala;
        double cadera = arriba + 48 * escala;
        double largoPierna = pies - cadera;

        g2.setColor(new Color(0, 0, 0, 80));
        g2.fill(new Ellipse2D.Double(cx - 22 * escala, ALTO_CANCHA - 4, 44 * escala, 10));

        dibujarPierna(g2, cx - 5 * escala * sentido, cadera, largoPierna, escala, sentido, 0, bota);

        g2.setColor(camiseta);
        g2.fill(new RoundRectangle2D.Double(cx - 11 * escala, yTorso, 22 * escala, cadera - yTorso, 8 * escala,
                8 * escala));
        g2.setColor(COLOR_SHORT);
        g2.fill(new RoundRectangle2D.Double(cx - 10 * escala, cadera - 4 * escala, 20 * escala, 7 * escala,
                3 * escala, 3 * escala));

        dibujarPierna(g2, cx + 4 * escala * sentido, cadera, largoPierna, escala, sentido,
                anguloPierna(jugador.getProgresoPatada()), bota);

        g2.setColor(oscurecer(piel, 0.85));
        g2.fill(new Ellipse2D.Double(cx - sentido * 22 * escala - 4 * escala, yCabeza + altoCabeza * 0.45,
                8 * escala, 11 * escala));

        Ellipse2D rostro = new Ellipse2D.Double(cx - anchoCabeza / 2, yCabeza, anchoCabeza, altoCabeza);
        g2.setColor(piel);
        g2.fill(rostro);

        Shape clipOriginal = g2.getClip();
        g2.clip(rostro);
        g2.setColor(pelo);
        g2.fill(new Rectangle2D.Double(cx - anchoCabeza / 2, yCabeza, anchoCabeza, altoCabeza * 0.3));
        double xAtras = (sentido == 1) ? cx - anchoCabeza / 2 : cx + anchoCabeza / 2 - anchoCabeza * 0.3;
        g2.fill(new Rectangle2D.Double(xAtras, yCabeza, anchoCabeza * 0.3, altoCabeza * 0.62));
        g2.setClip(clipOriginal);

        g2.setColor(pelo);
        g2.fill(new Ellipse2D.Double(cx + sentido * 4 * escala - 14 * escala, yCabeza - 4 * escala,
                28 * escala, 14 * escala));

        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(1.5f));
        g2.draw(rostro);

        double yOjo = yCabeza + altoCabeza * 0.52;
        double anchoOjo = 10 * escala;
        double altoOjo = 12 * escala;
        double[] posiciones = {5 * escala, 17 * escala};
        for (double p : posiciones){
            double xOjo = cx + sentido * p;
            g2.setColor(Color.WHITE);
            g2.fill(new Ellipse2D.Double(xOjo - anchoOjo / 2, yOjo - altoOjo / 2, anchoOjo, altoOjo));
            g2.setColor(Color.BLACK);
            g2.draw(new Ellipse2D.Double(xOjo - anchoOjo / 2, yOjo - altoOjo / 2, anchoOjo, altoOjo));
            double pupila = 5 * escala;
            g2.fill(new Ellipse2D.Double(xOjo + sentido * 2 * escala - pupila / 2, yOjo - pupila / 2, pupila,
                    pupila));
            g2.setStroke(new BasicStroke(2f));
            g2.draw(new Line2D.Double(xOjo - sentido * 5 * escala, yOjo - 9 * escala, xOjo + sentido * 5 * escala,
                    yOjo - 6 * escala));
            g2.setStroke(new BasicStroke(1.5f));
        }

        g2.setColor(oscurecer(piel, 0.8));
        g2.fill(new Ellipse2D.Double(cx + sentido * 23 * escala - 4 * escala, yCabeza + altoCabeza * 0.58,
                8 * escala, 7 * escala));

        double xBoca = cx + sentido * 11 * escala;
        double yBoca = yCabeza + altoCabeza * 0.82;
        g2.setColor(Color.BLACK);
        if (jugador.estaPateando() || jugador.estaAturdido()){
            g2.setColor(new Color(120, 20, 20));
            g2.fill(new Ellipse2D.Double(xBoca - 4 * escala, yBoca - 3 * escala, 8 * escala, 8 * escala));
            g2.setColor(Color.BLACK);
            g2.draw(new Ellipse2D.Double(xBoca - 4 * escala, yBoca - 3 * escala, 8 * escala, 8 * escala));
        } else {
            g2.drawArc((int) (xBoca - 6 * escala), (int) (yBoca - 4 * escala), (int) (12 * escala),
                    (int) (7 * escala), 200, 140);
        }
        g2.setStroke(new BasicStroke(1));

        int x = (int) (cx - jugador.getAncho() / 2);
        int yArriba = (int) arriba;
        int ancho = (int) jugador.getAncho();
        int altoEntero = (int) alto;
        if (jugador.estaAturdido()){
            g2.setColor(new Color(120, 200, 255, 160));
            g2.fillRect(x - 6, yArriba - 3, ancho + 12, altoEntero + 6);
            g2.setColor(Color.WHITE);
            g2.drawRect(x - 6, yArriba - 3, ancho + 12, altoEntero + 6);
        }
        if (jugador.estaLento()){
            g2.setColor(new Color(255, 120, 0, 150));
            g2.fillOval(x - 8, yArriba - 4, ancho + 16, altoEntero + 8);
        }
        if (jugador.estaConfundido()){
            g2.setColor(Color.MAGENTA);
            g2.setFont(new Font("SansSerif", Font.BOLD, 22));
            g2.drawString("?", x + ancho / 2 - 6, yArriba - 8);
        }
    }

    private void dibujarBalon(Graphics2D g2, Balon balon){
        double r = Balon.RADIO;
        double cx = balon.getX();
        double cy = balon.getY();

        double altura = Cancha.ALTO - cy;
        double factor = Math.max(0.3, 1 - altura / Cancha.ALTO);
        g2.setColor(new Color(0, 0, 0, 90));
        g2.fill(new Ellipse2D.Double(cx - r * 1.2 * factor, ALTO_CANCHA - 4, r * 2.4 * factor, 9));

        AffineTransform original = g2.getTransform();
        Shape clipOriginal = g2.getClip();
        g2.translate(cx, cy);
        g2.rotate(anguloBalon);

        Ellipse2D circulo = new Ellipse2D.Double(-r, -r, 2 * r, 2 * r);
        g2.setColor(Color.WHITE);
        g2.fill(circulo);
        g2.clip(circulo);

        g2.setColor(new Color(30, 30, 30));
        Path2D.Double centro = new Path2D.Double();
        for (int i = 0; i < 5; i++){
            double a = i * 2 * Math.PI / 5 - Math.PI / 2;
            double px = Math.cos(a) * r * 0.38;
            double py = Math.sin(a) * r * 0.38;
            if (i == 0){
                centro.moveTo(px, py);
            } else {
                centro.lineTo(px, py);
            }
        }
        centro.closePath();
        g2.fill(centro);

        g2.setStroke(new BasicStroke(1f));
        for (int i = 0; i < 5; i++){
            double a = i * 2 * Math.PI / 5 - Math.PI / 2;
            g2.draw(new Line2D.Double(
                    Math.cos(a) * r * 0.38, Math.sin(a) * r * 0.38,
                    Math.cos(a) * r * 0.75, Math.sin(a) * r * 0.75));
            double ap = a + Math.PI / 5;
            g2.fill(new Ellipse2D.Double(
                    Math.cos(ap) * r * 1.0 - r * 0.32, Math.sin(ap) * r * 1.0 - r * 0.32,
                    r * 0.64, r * 0.64));
        }

        g2.setTransform(original);
        g2.setClip(clipOriginal);

        g2.setColor(new Color(40, 40, 40));
        g2.setStroke(new BasicStroke(1.5f));
        g2.draw(new Ellipse2D.Double(cx - r, cy - r, 2 * r, 2 * r));
        g2.setStroke(new BasicStroke(1));
    }

    private void dibujarMarcador(Graphics2D g2, Partido partido){
        g2.setColor(new Color(30, 30, 30));
        g2.fillRect(0, 0, ANCHO, ALTO_MARCADOR);

        dibujarDatosJugador(g2, partido.getJugador1(), 15, COLOR_1);
        dibujarDatosJugador(g2, partido.getJugador2(), ANCHO - 245, COLOR_2);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 36));
        dibujarCentrado(g2, partido.getJugador1().getGoles() + "  -  " + partido.getJugador2().getGoles(), 50);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        dibujarCentrado(g2, textoModo(partido), 78);
    }

    private void dibujarDatosJugador(Graphics2D g2, Jugador jugador, int x, Color color){
        Personaje personaje = jugador.getPersonaje();
        g2.setColor(color);
        g2.fillRect(x, 8, 6, 84);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 13));
        g2.drawString(jugador.getNombre() + " - " + personaje.getNombre() + " (" + personaje.getPais() + ")",
                x + 14, 20);

        BarraDePoder barra = jugador.getBarraDePoder();
        int ancho = 200;
        int alto = 14;
        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(x + 14, 27, ancho, alto);
        g2.setColor(barra.estaLlena() ? Color.ORANGE : new Color(60, 180, 75));
        g2.fillRect(x + 14, 27, ancho * barra.getCarga() / MAXIMO_BARRA, alto);
        g2.setColor(Color.WHITE);
        g2.drawRect(x + 14, 27, ancho, alto);

        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
        String listo = barra.estaLlena() ? " (LISTO)" : "";
        g2.drawString("Goles: " + jugador.getGoles() + "   Poder: " + personaje.getPoder().getNombre() + listo,
                x + 14, 57);
        g2.drawString("Vel " + personaje.getVelocidad() + "  Salto " + personaje.getSalto()
                + "  Fuerza " + personaje.getFuerza(), x + 14, 73);

        Poder activo = jugador.getPoderActivo();
        String textoActivo = "Ninguno";
        if (activo != null){
            textoActivo = activo.getNombre() + " (" + (int) Math.ceil(jugador.getSegundosPoderActivo()) + " s)";
        }
        g2.setColor(activo != null ? Color.YELLOW : Color.LIGHT_GRAY);
        g2.drawString("Poder activo: " + textoActivo, x + 14, 89);
    }

    private String textoModo(Partido partido){
        String texto = partido.getTextoModo();
        if (juego.getTipo() == TipoPartido.SUPERVIVENCIA){
            texto += "  |  Ronda " + juego.getRonda();
        }
        return texto;
    }

    private void dibujarMensajes(Graphics2D g2, Partido partido){
        if (partido.estaTerminado()){
            sombrear(g2);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 40));
            dibujarCentrado(g2, "Ganador: " + partido.getGanador().getNombre(), ALTO_TOTAL / 2 - 10);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 18));
            boolean sigue = juego.getTipo() == TipoPartido.SUPERVIVENCIA
                    && partido.getGanador() == partido.getJugador1();
            dibujarCentrado(g2, sigue ? "ENTER: siguiente ronda" : "ENTER: volver al menú", ALTO_TOTAL / 2 + 30);
        } else if (partido.estaPausado()){
            sombrear(g2);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 40));
            dibujarCentrado(g2, "PAUSA", ALTO_TOTAL / 2 - 10);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 18));
            dibujarCentrado(g2, "P: reanudar   |   Esc: menú", ALTO_TOTAL / 2 + 30);
        } else if (partido.estaCelebrando()){
            g2.setColor(Color.YELLOW);
            g2.setFont(new Font("SansSerif", Font.BOLD, 64));
            dibujarCentrado(g2, "¡GOL!", ALTO_TOTAL / 2);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 22));
            dibujarCentrado(g2, partido.getUltimoAnotador().getNombre(), ALTO_TOTAL / 2 + 35);
        }
    }

    private void sombrear(Graphics2D g2){
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRect(0, ALTO_MARCADOR, ANCHO, ALTO_TOTAL - ALTO_MARCADOR);
    }

    private void dibujarCentrado(Graphics2D g2, String texto, int y){
        FontMetrics medidas = g2.getFontMetrics();
        g2.drawString(texto, (ANCHO - medidas.stringWidth(texto)) / 2, y);
    }
}