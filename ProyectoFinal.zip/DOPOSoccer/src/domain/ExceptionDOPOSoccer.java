package domain;

public class ExceptionDOPOSoccer extends Exception{

    public static final String ESTADISTICA_INVALIDA = "La estadistica debe estar entre 1 y 5";
    public static final String LADOS_INVALIDOS = "El jugador 1 debe jugar a la izquierda y el jugador 2 a la derecha";
    public static final String OBJETIVO_INVALIDO = "El objetivo de goles debe ser 3, 5 o 7";
    public static final String BALONES_INVALIDOS = "La cantidad de balones debe ser mayor que cero";
    public static final String SUPERVIVENCIA_SOLO_PVSM = "La supervivencia solo esta disponible en la modalidad jugador vs maquina";

    public ExceptionDOPOSoccer(String mensaje){
        super(mensaje);
    }
}

