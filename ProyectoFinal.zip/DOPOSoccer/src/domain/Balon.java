package domain;

public class Balon{

    public static final double RADIO = 12;
    private static final double RESTITUCION = 0.75;
    private static final double ROZAMIENTO_SUELO = 0.98;
    private static final double VELOCIDAD_MINIMA = 20;
    private double x;
    private double y;
    private double velocidadX;
    private double velocidadY;

    public Balon(double x, double y){
        reiniciar(x, y);
    }

    public void reiniciar(double x, double y){
        this.x = x;
        this.y = y;
        this.velocidadX = 0;
        this.velocidadY = 0;
    }

    public void actualizar(double segundos, double gravedad, double ancho, double alto){
        velocidadY += gravedad * segundos;
        x += velocidadX * segundos;
        y += velocidadY * segundos;

        if (y + RADIO > alto) {
            y = alto - RADIO;
            velocidadY = -velocidadY * RESTITUCION;
            velocidadX *= ROZAMIENTO_SUELO;
            if (Math.abs(velocidadY) < VELOCIDAD_MINIMA){
                velocidadY = 0;
            }
        }
        if (y - RADIO < 0){
            y = RADIO;
            velocidadY = -velocidadY * RESTITUCION;
        }
        if (x - RADIO < 0){
            x = RADIO;
            velocidadX = -velocidadX * RESTITUCION;
        }
        if (x + RADIO > ancho){
            x = ancho - RADIO;
            velocidadX = -velocidadX * RESTITUCION;
        }
    }

    public void apoyarEn(double yTope){
        y = yTope - RADIO;
        velocidadY = -velocidadY * RESTITUCION;
    }

    public void patear(double fuerzaX, double fuerzaY){
        velocidadX = fuerzaX;
        velocidadY = fuerzaY;
    }

    public double getX(){
        return x;
    }

    public double getY(){
        return y;
    }

    public double getVelocidadX(){
        return velocidadX;
    }

    public double getVelocidadY(){
        return velocidadY;
    }
}