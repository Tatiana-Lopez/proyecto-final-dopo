package domain;

public class PartidoSupervivencia extends Partido {
    
    private int balones1;
    private int balones2;

    public PartidoSupervivencia(Jugador jugador1, Jugador jugador2, int balones) throws ExceptionDOPOSoccer{
        super(jugador1, jugador2);
        if (balones <= 0){
            throw new ExceptionDOPOSoccer(ExceptionDOPOSoccer.BALONES_INVALIDOS);
        }
        this.balones1 = balones;
        this.balones2 = balones;
    }

    @Override
    protected void alMarcar(Jugador anotador, Jugador rival){
        if (rival == getJugador1()){
            balones1--;
        } else {
            balones2--;
        }
        if (getBalones(rival) == 0){
            terminar(anotador);
        }
    }

    @Override
    public String getTextoModo(){
        return "Balones " + balones1 + " - " + balones2;
    }

    public int getBalones(Jugador jugador){
        return (jugador == getJugador1()) ? balones1 : balones2;
    }
}