package domain;

public class PoderReduccion extends Poder{

    public PoderReduccion(){
        super("Reduccion", 5);
    }

    @Override
    public void aplicarA(Jugador oponente){
        oponente.reducir(getDuracionSegundos());
    }
}

