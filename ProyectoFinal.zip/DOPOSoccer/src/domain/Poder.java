package domain;

public abstract class Poder{
    
    private final String nombre;
    private final int duracionSegundos;

    public Poder(String nombre, int duracionSegundos){
        this.nombre = nombre;
        this.duracionSegundos = duracionSegundos;
    }

    public abstract void aplicarA(Jugador oponente);

    public String getNombre(){
        return nombre;
    }

    public int getDuracionSegundos(){
        return duracionSegundos;
    }
}
