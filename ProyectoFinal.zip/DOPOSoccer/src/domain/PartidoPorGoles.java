package domain;

public class PartidoPorGoles extends Partido{

    private final int objetivo;

    public PartidoPorGoles(Jugador jugador1, Jugador jugador2, int objetivo) throws ExceptionDOPOSoccer{
        super(jugador1, jugador2);
        if (objetivo != 3 && objetivo != 5 && objetivo != 7){
            throw new ExceptionDOPOSoccer(ExceptionDOPOSoccer.OBJETIVO_INVALIDO);
        }
        this.objetivo = objetivo;
    }

    @Override
    protected void alMarcar(Jugador anotador, Jugador rival){
        if (anotador.getGoles() >= objetivo){
            terminar(anotador);
        }
    }

    @Override
    public String getTextoModo(){
        return "A " + objetivo + " goles";
    }

    public int getObjetivo(){
        return objetivo;
    }
}