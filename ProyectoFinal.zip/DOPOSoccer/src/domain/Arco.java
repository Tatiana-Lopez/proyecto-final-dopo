package domain;

public class Arco{
    
    private final Lado lado;
    private final double xMinimo;
    private final double xMaximo;
    private final double yTravesano;
    private final double ySuelo;

    public Arco(Lado lado, double xMinimo, double xMaximo, double alto, double ySuelo){
        this.lado = lado;
        this.xMinimo = xMinimo;
        this.xMaximo = xMaximo;
        this.ySuelo = ySuelo;
        this.yTravesano = ySuelo - alto;
    }

    public boolean contiene(Balon balon){
        double r = Balon.RADIO;
        return balon.getX() - r >= xMinimo && balon.getX() + r <= xMaximo && balon.getY() - r >= yTravesano && balon.getY() + r <= ySuelo;
    }

    public boolean golpeaTravesano(Balon balon){
        double r = Balon.RADIO;
        return balon.getVelocidadY() > 0 && balon.getX() > xMinimo - r && balon.getX() < xMaximo + r && balon.getY() < yTravesano && balon.getY() + r >= yTravesano;
    }

    public Lado getLado(){
        return lado;
    }

    public double getXMinimo(){
        return xMinimo;
    }

    public double getXMaximo(){
        return xMaximo;
    }

    public double getYTravesano(){
        return yTravesano;
    }
}