package domain;

// Para esta clase nos apoyamos con la IA con el prompt de como se va a controlar el jugador 
public interface ControladorJugador{

    void actuar(Partido partido, Jugador jugador, double segundos);

    default void setIzquierda(boolean presionada){
    }

    default void setDerecha(boolean presionada){
    }

    default void setSaltar(boolean presionada){
    }

    default void setPatear(boolean presionada){
    }

    default void pedirPoder(){
    }
}