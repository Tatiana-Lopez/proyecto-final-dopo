package domain;
import java.util.HashSet;
import java.util.Set;

public abstract class Partido{

    private static final double RECARGA_POR_SEGUNDO = 10;
    private static final double VELOCIDAD_CHOQUE = 350;
    private final Cancha cancha;
    private final Jugador jugador1;
    private final Jugador jugador2;
    private final Set<Jugador> poderPreparado;
    private double segundosJugados;
    private double acumuladorRecarga;
    private boolean pausado;
    private boolean terminado;
    private Jugador ganador;

    public Partido(Jugador jugador1, Jugador jugador2) throws ExceptionDOPOSoccer{
        if (jugador1.getLado() != Lado.IZQUIERDO || jugador2.getLado() != Lado.DERECHO){
            throw new ExceptionDOPOSoccer(ExceptionDOPOSoccer.LADOS_INVALIDOS);
        }
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.cancha = new Cancha();
        this.poderPreparado = new HashSet<Jugador>();
        this.segundosJugados = 0;
        this.acumuladorRecarga = 0;
        this.pausado = false;
        this.terminado = false;
        this.ganador = null;
    }

    public void actualizar(double segundos){
        if (!estaActivo()){
            return;
        }
        segundosJugados += segundos;
        recargarBarras(segundos);
        actualizarJugador(jugador1, segundos);
        actualizarJugador(jugador2, segundos);
        Lado lado = cancha.actualizar(segundos);
        if (lado != null){
            registrarGol(lado);
        }
        verificarTiempo();
    }

    private void actualizarJugador(Jugador jugador, double segundos){
        jugador.actualizarFisica(segundos);
        jugador.avanzarTiempo(segundos);
        chocarConBalon(jugador);
    }

    private void recargarBarras(double segundos){
        acumuladorRecarga += RECARGA_POR_SEGUNDO * segundos;
        int cantidad = (int) acumuladorRecarga;
        if (cantidad > 0){
            acumuladorRecarga -= cantidad;
            jugador1.getBarraDePoder().recargar(cantidad);
            jugador2.getBarraDePoder().recargar(cantidad);
        }
    }

    private void chocarConBalon(Jugador jugador){
        Balon balon = cancha.getBalon();
        double dx = balon.getX() - jugador.getX();
        double dy = balon.getY() - (jugador.getY() - jugador.getAlto() / 2);
        double distancia = Math.sqrt(dx * dx + dy * dy);
        double minima = Balon.RADIO + jugador.getAncho() / 2;
        if (distancia < minima && distancia > 0){
            balon.patear(dx / distancia * VELOCIDAD_CHOQUE, dy / distancia * VELOCIDAD_CHOQUE);
        }
    }

    private void registrarGol(Lado ladoDelArco){
        Jugador dueno = (ladoDelArco == Lado.IZQUIERDO) ? jugador1 : jugador2;
        Jugador anotador = getOponente(dueno);
        anotador.anotarGol();
        reiniciarPosiciones();
        alMarcar(anotador, dueno);
    }

    private void reiniciarPosiciones(){
        jugador1.colocarEnInicio();
        jugador2.colocarEnInicio();
        cancha.reiniciarBalon();
    }

    public void mover(Jugador jugador, int direccion, double segundos){
        if (estaActivo()){
            jugador.mover(direccion, segundos);
        }
    }

    public void saltar(Jugador jugador){
        if (estaActivo()){
            jugador.saltar();
        }
    }

    public void patear(Jugador jugador){
        if (!estaActivo()){
            return;
        }
        boolean golpeo = jugador.patear(cancha.getBalon());
        if (golpeo && poderPreparado.remove(jugador)){
            jugador.usarPoder(getOponente(jugador));
        }
    }

    public void prepararPoder(Jugador jugador){
        if (estaActivo() && jugador.getBarraDePoder().estaLlena()){
            poderPreparado.add(jugador);
        }
    }

    public void pausar(){
        pausado = true;
    }

    public void reanudar(){
        pausado = false;
    }

    protected void terminar(Jugador ganador){
        this.ganador = ganador;
        this.terminado = true;
    }

    protected abstract void alMarcar(Jugador anotador, Jugador rival);

    public abstract String getTextoModo();

    protected void verificarTiempo(){
    }

    public Jugador getOponente(Jugador jugador){
        return (jugador == jugador1) ? jugador2 : jugador1;
    }

    public boolean estaActivo(){
        return !pausado && !terminado;
    }

    public boolean estaPausado(){
        return pausado;
    }

    public boolean estaTerminado(){
        return terminado;
    }

    public Jugador getGanador(){
        return ganador;
    }

    public double getSegundosJugados(){
        return segundosJugados;
    }

    public Cancha getCancha(){
        return cancha;
    }

    public Jugador getJugador1(){
        return jugador1;
    }

    public Jugador getJugador2(){
        return jugador2;
    }
}