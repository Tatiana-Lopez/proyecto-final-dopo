package domain;

public enum Modalidad {
    PVSP,
    PVSM,
    MVSM
}
