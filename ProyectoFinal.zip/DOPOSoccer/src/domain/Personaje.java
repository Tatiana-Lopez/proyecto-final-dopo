package domain;

public class Personaje{

    private final String nombre;
    private final Pais pais;
    private final int velocidad;
    private final int salto;
    private final int fuerza;
    private final Poder poder;

    public Personaje(String nombre, Pais pais, int velocidad, int salto, int fuerza, Poder poder) throws ExceptionDOPOSoccer{

        this.nombre = nombre;
        this.pais = pais;
        this.velocidad = validar(velocidad);
        this.salto = validar(salto);
        this.fuerza = validar(fuerza);
        this.poder = poder;
    }

    private int validar(int valor) throws ExceptionDOPOSoccer{
        if (valor < 1 || valor > 5) {
            throw new ExceptionDOPOSoccer(ExceptionDOPOSoccer.ESTADISTICA_INVALIDA);
        }
        return valor;
    }

    public String getNombre(){
        return nombre;
    }

    public Pais getPais(){
        return pais;
    }

    public int getVelocidad(){
        return velocidad;
    }

    public int getSalto(){
        return salto;
    }

    public int getFuerza(){
        return fuerza;
    }

    public Poder getPoder(){
        return poder;
    }
}