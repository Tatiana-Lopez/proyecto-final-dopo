package domain;

public enum Pais{
    CANADA,
    COLOMBIA,
    BRASIL,
    JAPON,
    ALEMANIA
}

