package domain;

public enum Lado{
    IZQUIERDO,
    DERECHO
}

