package domain;

public class Cancha{
    
    public static final double ANCHO = 900;
    public static final double ALTO = 450;
    public static final double GRAVEDAD = 900;
    private static final double ANCHO_ARCO = 70;
    private static final double ALTO_ARCO = 140;
    private static final double ALTURA_INICIAL_BALON = 100;
    private final Balon balon;
    private final Arco arcoIzquierdo;
    private final Arco arcoDerecho;

    public Cancha(){
        balon = new Balon(ANCHO / 2, ALTURA_INICIAL_BALON);
        arcoIzquierdo = new Arco(Lado.IZQUIERDO, 0, ANCHO_ARCO, ALTO_ARCO, ALTO);
        arcoDerecho = new Arco(Lado.DERECHO, ANCHO - ANCHO_ARCO, ANCHO, ALTO_ARCO, ALTO);
    }

    public void reiniciarBalon(){
        balon.reiniciar(ANCHO / 2, ALTURA_INICIAL_BALON);
    }

    public Lado actualizar(double segundos){
        balon.actualizar(segundos, GRAVEDAD, ANCHO, ALTO);
        rebotarEnTravesano(arcoIzquierdo);
        rebotarEnTravesano(arcoDerecho);

        if (arcoIzquierdo.contiene(balon)){
            return Lado.IZQUIERDO;
        }
        if (arcoDerecho.contiene(balon)){
            return Lado.DERECHO;
        }
        return null;
    }

    private void rebotarEnTravesano(Arco arco){
        if (arco.golpeaTravesano(balon)){
            balon.apoyarEn(arco.getYTravesano());
        }
    }

    public Balon getBalon(){
        return balon;
    }

    public Arco getArcoIzquierdo(){
        return arcoIzquierdo;
    }

    public Arco getArcoDerecho(){
        return arcoDerecho;
    }
}