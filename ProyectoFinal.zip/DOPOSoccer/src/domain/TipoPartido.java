package domain;

public enum TipoPartido{
    POR_TIEMPO,
    POR_GOLES,
    SUPERVIVENCIA
}

