package domain;

public class PoderCongelacion extends Poder{

    public PoderCongelacion(){
        super("Congelacion", 3);
    }

    @Override
    public void aplicarA(Jugador oponente){
        oponente.aturdir(getDuracionSegundos());
    }
}