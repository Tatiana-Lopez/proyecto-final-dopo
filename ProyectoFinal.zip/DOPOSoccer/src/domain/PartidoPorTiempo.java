package domain;

public class PartidoPorTiempo extends Partido{

    public static final double DURACION = 60;
    private boolean golDeOro;

    public PartidoPorTiempo(Jugador jugador1, Jugador jugador2) throws ExceptionDOPOSoccer{
        super(jugador1, jugador2);
        this.golDeOro = false;
    }

    @Override
    protected void verificarTiempo(){
        if (golDeOro || getSegundosJugados() < DURACION){
            return;
        }
        int goles1 = getJugador1().getGoles();
        int goles2 = getJugador2().getGoles();
        if (goles1 > goles2){
            terminar(getJugador1());
        } else if (goles2 > goles1){
            terminar(getJugador2());
        } else {
            golDeOro = true;
        }
    }

    @Override
    protected void alMarcar(Jugador anotador, Jugador rival){
        if (golDeOro){
            terminar(anotador);
        }
    }

    @Override
    public String getTextoModo(){
        if (golDeOro){
            return "GOL DE ORO";
        }
        return "Tiempo: " + (int) Math.ceil(getSegundosRestantes());
    }

    public double getSegundosRestantes(){
        return Math.max(0, DURACION - getSegundosJugados());
    }

    public boolean estaEnGolDeOro(){
        return golDeOro;
    }
}