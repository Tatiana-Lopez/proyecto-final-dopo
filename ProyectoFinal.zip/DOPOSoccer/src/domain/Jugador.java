package domain;

public class Jugador {

    private static final double SEGUNDOS_ATURDIMIENTO = 3.0;
    private static final double ANCHO_BASE = 40;
    private static final double ALTO_BASE = 60;
    private static final double ESCALA_REDUCIDO = 0.5;
    private static final double PIXELES_POR_VELOCIDAD = 60;
    private static final double SALTO_BASE = 300;
    private static final double SALTO_POR_NIVEL = 60;
    private static final double ALCANCE_PATADA = 30;
    private static final double FUERZA_BASE = 250;
    private static final double FUERZA_POR_NIVEL = 80;
    private static final double IMPULSO_VERTICAL = -300;
    private static final double DISTANCIA_INICIAL = 150;
    private final String nombre;
    private final Personaje personaje;
    private final Lado lado;
    private final BarraDePoder barraDePoder;
    private int goles;
    private double segundosAturdido;
    private double segundosReducido;
    private double segundosConfundido;
    private Poder poderActivo;
    private double x;
    private double y;
    private double velocidadY;

    public Jugador(String nombre, Personaje personaje, Lado lado){
        this.nombre = nombre;
        this.personaje = personaje;
        this.lado = lado;
        this.barraDePoder = new BarraDePoder();
        this.goles = 0;
        this.segundosAturdido = 0;
        this.segundosReducido = 0;
        this.segundosConfundido = 0;
        this.poderActivo = null;
        colocarEnInicio();
    }

    public void colocarEnInicio(){
        x = (lado == Lado.IZQUIERDO) ? DISTANCIA_INICIAL : Cancha.ANCHO - DISTANCIA_INICIAL;
        y = Cancha.ALTO;
        velocidadY = 0;
    }

    public void mover(int direccion, double segundos){
        if (estaAturdido()){
            return;
        }
        if (estaConfundido()){
            direccion = -direccion;
        }
        x += direccion * personaje.getVelocidad() * PIXELES_POR_VELOCIDAD * segundos;
        double mitad = getAncho() / 2;
        x = Math.max(mitad, Math.min(Cancha.ANCHO - mitad, x));
    }

    public void saltar(){
        if (estaAturdido() || !estaEnSuelo()){
            return;
        }
        velocidadY = -(SALTO_BASE + SALTO_POR_NIVEL * personaje.getSalto());
    }

    public boolean patear(Balon balon){
        if (estaAturdido()){
            return false;
        }
        double dx = balon.getX() - x;
        double dy = balon.getY() - (y - getAlto() / 2);
        double distancia = Math.sqrt(dx * dx + dy * dy);
        if (distancia > ALCANCE_PATADA + Balon.RADIO + getAncho() / 2){
            return false;
        }
        int sentido = (lado == Lado.IZQUIERDO) ? 1 : -1;
        double fuerza = FUERZA_BASE + FUERZA_POR_NIVEL * personaje.getFuerza();
        balon.patear(sentido * fuerza, IMPULSO_VERTICAL);
        return true;
    }

    public void actualizarFisica(double segundos){
        velocidadY += Cancha.GRAVEDAD * segundos;
        y += velocidadY * segundos;
        if (y >= Cancha.ALTO){
            y = Cancha.ALTO;
            velocidadY = 0;
        }
    }

    public void avanzarTiempo(double segundos){
        segundosAturdido = Math.max(0, segundosAturdido - segundos);
        segundosReducido = Math.max(0, segundosReducido - segundos);
        segundosConfundido = Math.max(0, segundosConfundido - segundos);
    }

    public boolean usarPoder(Jugador oponente){
        if (!barraDePoder.estaLlena()){
            return false;
        }
        Poder poder = personaje.getPoder();
        poder.aplicarA(oponente);
        poderActivo = poder;
        barraDePoder.vaciar();
        return true;
    }

    public void anotarGol(){
        goles++;
    }

    public void aturdir(){
        segundosAturdido = SEGUNDOS_ATURDIMIENTO;
    }

    public void aturdir(double segundos){
        segundosAturdido = segundos;
    }

    public void reducir(double segundos){
        segundosReducido = segundos;
    }

    public void confundir(double segundos){
        segundosConfundido = segundos;
    }

    public boolean estaAturdido(){
        return segundosAturdido > 0;
    }

    public boolean estaReducido(){
        return segundosReducido > 0;
    }

    public boolean estaConfundido(){
        return segundosConfundido > 0;
    }

    public boolean estaEnSuelo(){
        return y >= Cancha.ALTO;
    }

    public double getAncho(){
        return estaReducido() ? ANCHO_BASE * ESCALA_REDUCIDO : ANCHO_BASE;
    }

    public double getAlto(){
        return estaReducido() ? ALTO_BASE * ESCALA_REDUCIDO : ALTO_BASE;
    }

    public String getNombre(){
        return nombre;
    }

    public Personaje getPersonaje(){
        return personaje;
    }

    public Lado getLado(){
        return lado;
    }

    public BarraDePoder getBarraDePoder(){
        return barraDePoder;
    }

    public int getGoles(){
        return goles;
    }

    public Poder getPoderActivo(){
        return poderActivo;
    }

    public double getX(){
        return x;
    }

    public double getY(){
        return y;
    }
}