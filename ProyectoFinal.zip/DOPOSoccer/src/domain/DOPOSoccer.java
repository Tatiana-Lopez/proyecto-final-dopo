package domain;

public class DOPOSoccer{
    
    private static final int BALONES_SUPERVIVENCIA = 3;
    private Partido partido;
    private Modalidad modalidad;
    private TipoPartido tipo;
    private int parametro;
    private Pais pais1;
    private Pais pais2;
    private ControladorJugador controlador1;
    private ControladorJugador controlador2;
    private int ronda;

    public DOPOSoccer(){
        partido = null;
        ronda = 0;
    }

    public void iniciarPartido(Modalidad modalidad, TipoPartido tipo, int parametro, Pais pais1, Pais pais2)
            throws ExceptionDOPOSoccer{
        if (tipo == TipoPartido.SUPERVIVENCIA && modalidad != Modalidad.PVSM){
            throw new ExceptionDOPOSoccer(ExceptionDOPOSoccer.SUPERVIVENCIA_SOLO_PVSM);
        }

        this.modalidad = modalidad;
        this.tipo = tipo;
        this.parametro = parametro;
        this.pais1 = pais1;
        this.pais2 = pais2;
        this.ronda = 1;
        crearControladores();
        crearPartido();
    }

    private void crearControladores(){
        if (modalidad == Modalidad.PVSP){
            controlador1 = new ControladorHumano();
            controlador2 = new ControladorHumano();
        } else if (modalidad == Modalidad.PVSM){
            controlador1 = new ControladorHumano();
            controlador2 = new ControladorMaquina();
        } else {
            controlador1 = new ControladorMaquina();
            controlador2 = new ControladorMaquina();
        }
    }

    private void crearPartido() throws ExceptionDOPOSoccer{
        Jugador jugador1 = new Jugador("Jugador 1", crearPersonaje(pais1), Lado.IZQUIERDO);
        String nombre2 = (modalidad == Modalidad.PVSP) ? "Jugador 2" : "Maquina";
        Jugador jugador2 = new Jugador(nombre2, crearPersonaje(pais2), Lado.DERECHO);
        if (tipo == TipoPartido.POR_TIEMPO){
            partido = new PartidoPorTiempo(jugador1, jugador2);
        } else if (tipo == TipoPartido.POR_GOLES){
            partido = new PartidoPorGoles(jugador1, jugador2, parametro);
        } else {
            partido = new PartidoSupervivencia(jugador1, jugador2, BALONES_SUPERVIVENCIA);
        }
    }

    private Personaje crearPersonaje(Pais pais) throws ExceptionDOPOSoccer{
        switch (pais){
            case CANADA:
                return new Personaje("Canada", pais, 3, 3, 4, new PoderCongelacion());
            case COLOMBIA:
                return new Personaje("Colombia", pais, 4, 4, 3, new PoderReduccion());
            case BRASIL:
                return new Personaje("Brasil", pais, 5, 3, 3, new PoderConfusion());
            case JAPON:
                return new Personaje("Japon", pais, 5, 4, 2, new PoderCongelacion());
            default:
                return new Personaje("Alemania", pais, 2, 3, 5, new PoderConfusion());
        }
    }

    public boolean siguienteRonda() throws ExceptionDOPOSoccer{
        if (tipo != TipoPartido.SUPERVIVENCIA || partido == null || !partido.estaTerminado()){
            return false;
        }
        if (partido.getGanador() != partido.getJugador1()){
            return false;
        }
        ronda++;
        Pais[] paises = Pais.values();
        pais2 = paises[(pais2.ordinal() + 1) % paises.length];
        crearPartido();
        return true;
    }

    public void actualizar(double segundos){
        if (partido == null || !partido.estaActivo()){
            return;
        }
        controlador1.actuar(partido, partido.getJugador1(), segundos);
        controlador2.actuar(partido, partido.getJugador2(), segundos);
        partido.actualizar(segundos);
    }

    public void pausar(){
        if (partido != null){
            partido.pausar();
        }
    }

    public void reanudar(){
        if (partido != null){
            partido.reanudar();
        }
    }

    public Partido getPartido(){
        return partido;
    }

    public Modalidad getModalidad(){
        return modalidad;
    }

    public TipoPartido getTipo(){
        return tipo;
    }

    public int getRonda(){
        return ronda;
    }

    public ControladorJugador getControlador1(){
        return controlador1;
    }

    public ControladorJugador getControlador2(){
        return controlador2;
    }
}