package domain;

public class PoderConfusion extends Poder{

    public PoderConfusion(){
        super("Confusion", 5);
    }

    @Override
    public void aplicarA(Jugador oponente){
        oponente.confundir(getDuracionSegundos());
    }
}

