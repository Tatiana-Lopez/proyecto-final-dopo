package domain;

public class ControladorHumano implements ControladorJugador{

    private boolean izquierda;
    private boolean derecha;
    private boolean saltar;
    private boolean patear;
    private boolean poder;

    public ControladorHumano(){
        izquierda = false;
        derecha = false;
        saltar = false;
        patear = false;
        poder = false;
    }

    @Override
    public void setIzquierda(boolean presionada){
        izquierda = presionada;
    }

    @Override
    public void setDerecha(boolean presionada){
        derecha = presionada;
    }

    @Override
    public void setSaltar(boolean presionada){
        saltar = presionada;
    }

    @Override
    public void setPatear(boolean presionada){
        patear = presionada;
    }

    @Override
    public void pedirPoder(){
        poder = true;
    }

    @Override
    public void actuar(Partido partido, Jugador jugador, double segundos){
        int direccion = 0;
        if (izquierda){
            direccion -= 1;
        }
        if (derecha){
            direccion += 1;
        }
        partido.mover(jugador, direccion, segundos);
        if (saltar){
            partido.saltar(jugador);
        }
        if (patear){
            partido.patear(jugador);
        }
        if (poder){
            partido.prepararPoder(jugador);
            poder = false;
        }
    }
}