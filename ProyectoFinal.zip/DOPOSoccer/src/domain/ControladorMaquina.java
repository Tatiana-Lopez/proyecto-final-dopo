package domain;

public class ControladorMaquina implements ControladorJugador{
    
    private static final double MARGEN_DETRAS = 25;
    private static final double TOLERANCIA = 8;
    private static final double DISTANCIA_SALTO = 80;

    @Override
    public void actuar(Partido partido, Jugador jugador, double segundos){
        Balon balon = partido.getCancha().getBalon();
        int sentido = (jugador.getLado() == Lado.IZQUIERDO) ? 1 : -1;

        double meta = balon.getX() - sentido * MARGEN_DETRAS;
        double diferencia = meta - jugador.getX();
        int direccion = 0;
        if (Math.abs(diferencia) > TOLERANCIA){
            direccion = (diferencia > 0) ? 1 : -1;
        }
        partido.mover(jugador, direccion, segundos);

        double distanciaX = Math.abs(balon.getX() - jugador.getX());
        if (distanciaX < DISTANCIA_SALTO && balon.getY() < jugador.getY() - jugador.getAlto()){
            partido.saltar(jugador);
        }

        partido.patear(jugador);

        if (jugador.getBarraDePoder().estaLlena()){
            partido.prepararPoder(jugador);
        }
    }
}