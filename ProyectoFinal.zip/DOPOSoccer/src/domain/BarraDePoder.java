package domain;

public class BarraDePoder{

    private static final int MAXIMO = 100;
    private int carga;

    public BarraDePoder(){
        carga = 0;
    }

    public void recargar(int cantidad){
        carga = Math.min(MAXIMO, carga + cantidad);
    }

    public boolean estaLlena(){
        return carga == MAXIMO;
    }

    public void vaciar(){
        carga = 0;
    }

    public int getCarga(){
        return carga;
    }
}
