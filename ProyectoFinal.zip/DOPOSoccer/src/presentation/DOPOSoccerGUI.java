package presentation;
import domain.DOPOSoccer;
import domain.ExceptionDOPOSoccer;
import domain.Modalidad;
import domain.Pais;
import domain.TipoPartido;
import javax.swing.*;
import java.awt.*;

public class DOPOSoccerGUI extends JFrame{
    private static final String MENU = "menu";
    private static final String CONFIGURACION = "configuracion";
    private static final String CANCHA = "cancha";

    private final DOPOSoccer juego;
    private final CardLayout tarjetas;
    private final JPanel contenedor;
    private final PanelCancha panelCancha;

    public DOPOSoccerGUI(){
        super("DOPOSoccer");
        juego = new DOPOSoccer();
        tarjetas = new CardLayout();
        contenedor = new JPanel(tarjetas);
        panelCancha = new PanelCancha(this);
        contenedor.add(new PanelMenu(this), MENU);
        contenedor.add(new PanelConfiguracion(this), CONFIGURACION);
        contenedor.add(panelCancha, CANCHA);
        add(contenedor);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    public void mostrarMenu(){
        panelCancha.detener();
        tarjetas.show(contenedor, MENU);
    }

    public void mostrarConfiguracion(){
        tarjetas.show(contenedor, CONFIGURACION);
    }

    public void iniciarJuego(Modalidad modalidad, TipoPartido tipo, int objetivo, Pais pais1, Pais pais2){
        try {
            juego.iniciarPartido(modalidad, tipo, objetivo, pais1, pais2);
            panelCancha.iniciar(juego);
            tarjetas.show(contenedor, CANCHA);
            panelCancha.requestFocusInWindow();
        } catch (ExceptionDOPOSoccer e){
            JOptionPane.showMessageDialog(this, e.getMessage(), "No se puede iniciar", JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args){
        SwingUtilities.invokeLater(() -> {
            DOPOSoccerGUI ventana = new DOPOSoccerGUI();
            ventana.setVisible(true);
        });
    }
}