package presentation;
import javax.swing.*;
import java.awt.*;

public class PanelMenu extends JPanel{

    public PanelMenu(DOPOSoccerGUI ventana){
        setLayout(new GridBagLayout());
        setBackground(new Color(20, 90, 40));

        JPanel caja = new JPanel(new GridLayout(0, 1, 0, 15));
        caja.setOpaque(false);

        JLabel titulo = new JLabel("DOPOSoccer", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 48));
        titulo.setForeground(Color.WHITE);

        JButton jugar = new JButton("Jugar");
        JButton salir = new JButton("Salir");
        jugar.addActionListener(e -> ventana.mostrarConfiguracion());
        salir.addActionListener(e -> System.exit(0));

        caja.add(titulo);
        caja.add(jugar);
        caja.add(salir);
        add(caja);
    }
}