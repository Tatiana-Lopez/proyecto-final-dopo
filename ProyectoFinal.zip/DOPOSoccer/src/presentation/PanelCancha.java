package presentation;
import domain.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class PanelCancha extends JPanel{

    private static final int ALTO_MARCADOR = 80;
    private static final int ALTO_PASTO = 20;
    private static final int ANCHO = (int) Cancha.ANCHO;
    private static final int ALTO_CANCHA = (int) Cancha.ALTO;
    private static final int ALTO_TOTAL = ALTO_MARCADOR + ALTO_CANCHA + ALTO_PASTO;
    private static final int RETARDO_MS = 16;
    private static final int MAXIMO_BARRA = 100;
    private static final Color COLOR_1 = new Color(220, 40, 40);
    private static final Color COLOR_2 = new Color(40, 80, 220);
    private static final Color PIEL = new Color(255, 220, 177);
    private final DOPOSoccerGUI ventana;
    private final Timer temporizador;
    private DOPOSoccer juego;
    private long ultimoInstante;

    public PanelCancha(DOPOSoccerGUI ventana){
        this.ventana = ventana;
        setPreferredSize(new Dimension(ANCHO, ALTO_TOTAL));
        setFocusable(true);
        temporizador = new Timer(RETARDO_MS, e -> avanzar());
        addKeyListener(new KeyAdapter(){
            @Override
            public void keyPressed(KeyEvent e){
                procesarTecla(e, true);
            }

            @Override
            public void keyReleased(KeyEvent e){
                procesarTecla(e, false);
            }
        });
    }

    public void iniciar(DOPOSoccer juego){
        this.juego = juego;
        ultimoInstante = System.nanoTime();
        temporizador.start();
        SwingUtilities.invokeLater(() -> requestFocusInWindow());
    }

    public void detener(){
        temporizador.stop();
    }

    private void avanzar(){
        long ahora = System.nanoTime();
        double segundos = Math.min((ahora - ultimoInstante) / 1e9, 0.05);
        ultimoInstante = ahora;
        juego.actualizar(segundos);
        repaint();
    }

    private void procesarTecla(KeyEvent e, boolean presionada){
        if (juego == null){
            return;
        }
        teclasJugador1(juego.getControlador1(), e.getKeyCode(), presionada);
        teclasJugador2(juego.getControlador2(), e, presionada);
        if (presionada){
            teclasGenerales(e.getKeyCode());
        }
    }

    private void teclasJugador1(ControladorJugador c, int tecla, boolean presionada){
        switch (tecla){
            case KeyEvent.VK_A:
                c.setIzquierda(presionada);
                break;
            case KeyEvent.VK_D:
                c.setDerecha(presionada);
                break;
            case KeyEvent.VK_W:
                c.setSaltar(presionada);
                break;
            case KeyEvent.VK_S:
                c.setPatear(presionada);
                break;
            case KeyEvent.VK_Q:
                if (presionada){
                    c.pedirPoder();
                }
                break;
            default:
                break;
        }
    }

    private void teclasJugador2(ControladorJugador c, KeyEvent e, boolean presionada){
        switch (e.getKeyCode()){
            case KeyEvent.VK_LEFT:
                c.setIzquierda(presionada);
                break;
            case KeyEvent.VK_RIGHT:
                c.setDerecha(presionada);
                break;
            case KeyEvent.VK_UP:
                c.setSaltar(presionada);
                break;
            case KeyEvent.VK_DOWN:
                c.setPatear(presionada);
                break;
            case KeyEvent.VK_CONTROL:
                if (presionada && e.getKeyLocation() == KeyEvent.KEY_LOCATION_RIGHT){
                    c.pedirPoder();
                }
                break;
            default:
                break;
        }
    }

    private void teclasGenerales(int tecla){
        if (tecla == KeyEvent.VK_P){
            alternarPausa();
        } else if (tecla == KeyEvent.VK_ENTER){
            continuar();
        } else if (tecla == KeyEvent.VK_ESCAPE){
            ventana.mostrarMenu();
        }
    }

    private void alternarPausa(){
        Partido partido = juego.getPartido();
        if (partido.estaTerminado()){
            return;
        }
        if (partido.estaPausado()){
            juego.reanudar();
        } else {
            juego.pausar();
        }
    }

    private void continuar(){
        if (!juego.getPartido().estaTerminado()){
            return;
        }
        try {
            if (!juego.siguienteRonda()){
                ventana.mostrarMenu();
            }
        } catch (ExceptionDOPOSoccer ex){
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ventana.mostrarMenu();
        }
    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        if (juego == null || juego.getPartido() == null){
            return;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Partido partido = juego.getPartido();

        dibujarMarcador(g2, partido);

        g2.translate(0, ALTO_MARCADOR);
        dibujarCancha(g2, partido.getCancha());
        dibujarJugador(g2, partido.getJugador1(), COLOR_1);
        dibujarJugador(g2, partido.getJugador2(), COLOR_2);
        dibujarBalon(g2, partido.getCancha().getBalon());
        g2.translate(0, -ALTO_MARCADOR);

        dibujarMensajes(g2, partido);
        g2.dispose();
    }

    private void dibujarCancha(Graphics2D g2, Cancha cancha){
        g2.setColor(new Color(135, 206, 235));
        g2.fillRect(0, 0, ANCHO, ALTO_CANCHA);
        g2.setColor(new Color(34, 139, 34));
        g2.fillRect(0, ALTO_CANCHA, ANCHO, ALTO_PASTO);
        dibujarArco(g2, cancha.getArcoIzquierdo());
        dibujarArco(g2, cancha.getArcoDerecho());
    }

    private void dibujarArco(Graphics2D g2, Arco arco){
        int x = (int) arco.getXMinimo();
        int y = (int) arco.getYTravesano();
        int ancho = (int) (arco.getXMaximo() - arco.getXMinimo());
        int alto = ALTO_CANCHA - y;
        g2.setColor(new Color(255, 255, 255, 90));
        g2.fillRect(x, y, ancho, alto);
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(4));
        g2.drawRect(x, y, ancho, alto);
        g2.setStroke(new BasicStroke(1));
    }

    private void dibujarJugador(Graphics2D g2, Jugador jugador, Color color){
        int ancho = (int) jugador.getAncho();
        int alto = (int) jugador.getAlto();
        int x = (int) (jugador.getX() - ancho / 2.0);
        int yArriba = (int) (jugador.getY() - alto);
        int cabeza = ancho;

        g2.setColor(color);
        g2.fillRoundRect(x, yArriba + cabeza * 3 / 4, ancho, alto - cabeza * 3 / 4, 8, 8);
        g2.setColor(PIEL);
        g2.fillOval(x, yArriba, cabeza, cabeza);
        g2.setColor(Color.BLACK);
        g2.drawOval(x, yArriba, cabeza, cabeza);

        int sentido = (jugador.getLado() == Lado.IZQUIERDO) ? 1 : -1;
        int ojo = Math.max(2, cabeza / 6);
        g2.fillOval(x + cabeza / 2 + sentido * cabeza / 5 - ojo / 2, yArriba + cabeza / 3, ojo, ojo);

        if (jugador.estaAturdido()){
            g2.setColor(new Color(120, 200, 255, 160));
            g2.fillRect(x - 3, yArriba - 3, ancho + 6, alto + 6);
            g2.setColor(Color.WHITE);
            g2.drawRect(x - 3, yArriba - 3, ancho + 6, alto + 6);
        }
        if (jugador.estaConfundido()){
            g2.setColor(Color.MAGENTA);
            g2.setFont(new Font("SansSerif", Font.BOLD, 22));
            g2.drawString("?", x + ancho / 2 - 6, yArriba - 6);
        }
    }

    private void dibujarBalon(Graphics2D g2, Balon balon){
        int diametro = (int) (Balon.RADIO * 2);
        int x = (int) (balon.getX() - Balon.RADIO);
        int y = (int) (balon.getY() - Balon.RADIO);
        g2.setColor(Color.WHITE);
        g2.fillOval(x, y, diametro, diametro);
        g2.setColor(Color.BLACK);
        g2.drawOval(x, y, diametro, diametro);
    }

    private void dibujarMarcador(Graphics2D g2, Partido partido){
        g2.setColor(new Color(30, 30, 30));
        g2.fillRect(0, 0, ANCHO, ALTO_MARCADOR);

        dibujarDatosJugador(g2, partido.getJugador1(), 15, COLOR_1);
        dibujarDatosJugador(g2, partido.getJugador2(), ANCHO - 215, COLOR_2);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 36));
        dibujarCentrado(g2, partido.getJugador1().getGoles() + "  -  " + partido.getJugador2().getGoles(), 45);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
        dibujarCentrado(g2, textoModo(partido), 68);
    }

    private void dibujarDatosJugador(Graphics2D g2, Jugador jugador, int x, Color color){
        g2.setColor(color);
        g2.fillRect(x, 10, 6, 60);
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.BOLD, 14));
        g2.drawString(jugador.getNombre() + " - " + jugador.getPersonaje().getNombre(), x + 14, 24);

        BarraDePoder barra = jugador.getBarraDePoder();
        int ancho = 180;
        int alto = 14;
        g2.setColor(Color.DARK_GRAY);
        g2.fillRect(x + 14, 32, ancho, alto);
        g2.setColor(barra.estaLlena() ? Color.ORANGE : new Color(60, 180, 75));
        g2.fillRect(x + 14, 32, ancho * barra.getCarga() / MAXIMO_BARRA, alto);
        g2.setColor(Color.WHITE);
        g2.drawRect(x + 14, 32, ancho, alto);

        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));
        String estado = barra.estaLlena() ? " (LISTO)" : "";
        g2.drawString("Poder: " + jugador.getPersonaje().getPoder().getNombre() + estado, x + 14, 64);
    }

    private String textoModo(Partido partido){
        String texto = partido.getTextoModo();
        if (juego.getTipo() == TipoPartido.SUPERVIVENCIA){
            texto += "  |  Ronda " + juego.getRonda();
        }
        return texto;
    }

    private void dibujarMensajes(Graphics2D g2, Partido partido){
        if (partido.estaTerminado()){
            sombrear(g2);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 40));
            dibujarCentrado(g2, "Ganador: " + partido.getGanador().getNombre(), ALTO_TOTAL / 2 - 10);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 18));
            boolean sigue = juego.getTipo() == TipoPartido.SUPERVIVENCIA
                    && partido.getGanador() == partido.getJugador1();
            dibujarCentrado(g2, sigue ? "ENTER: siguiente ronda" : "ENTER: volver al menú", ALTO_TOTAL / 2 + 30);
        } else if (partido.estaPausado()){
            sombrear(g2);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("SansSerif", Font.BOLD, 40));
            dibujarCentrado(g2, "PAUSA", ALTO_TOTAL / 2 - 10);
            g2.setFont(new Font("SansSerif", Font.PLAIN, 18));
            dibujarCentrado(g2, "P: reanudar   |   Esc: menú", ALTO_TOTAL / 2 + 30);
        }
    }

    private void sombrear(Graphics2D g2){
        g2.setColor(new Color(0, 0, 0, 150));
        g2.fillRect(0, ALTO_MARCADOR, ANCHO, ALTO_TOTAL - ALTO_MARCADOR);
    }

    private void dibujarCentrado(Graphics2D g2, String texto, int y){
        FontMetrics medidas = g2.getFontMetrics();
        g2.drawString(texto, (ANCHO - medidas.stringWidth(texto)) / 2, y);
    }
}