package presentation;

import domain.Modalidad;
import domain.Pais;
import domain.TipoPartido;
import javax.swing.*;
import java.awt.*;

public class PanelConfiguracion extends JPanel{

    private final JComboBox<String> comboModalidad;
    private final JComboBox<String> comboTipo;
    private final JComboBox<String> comboObjetivo;
    private final JComboBox<Pais> comboPais1;
    private final JComboBox<Pais> comboPais2;

    public PanelConfiguracion(DOPOSoccerGUI ventana){
        setLayout(new GridBagLayout());
        setBackground(new Color(20, 90, 40));

        comboModalidad = new JComboBox<String>(
                new String[]{"Jugador vs Jugador", "Jugador vs Maquina", "Maquina vs Maquina"});
        comboTipo = new JComboBox<String>(new String[]{"Por tiempo (60 s)", "Por goles", "Supervivencia"});
        comboObjetivo = new JComboBox<String>(new String[]{"3", "5", "7"});
        comboPais1 = new JComboBox<Pais>(Pais.values());
        comboPais2 = new JComboBox<Pais>(Pais.values());
        comboPais2.setSelectedIndex(1);
        comboObjetivo.setEnabled(false);
        comboTipo.addActionListener(e -> comboObjetivo.setEnabled(comboTipo.getSelectedIndex() == 1));

        JLabel titulo = new JLabel("Configurar partido", SwingConstants.CENTER);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 30));
        titulo.setForeground(Color.WHITE);

        JPanel formulario = new JPanel(new GridLayout(0, 2, 10, 10));
        formulario.setOpaque(false);
        agregarFila(formulario, "Modalidad", comboModalidad);
        agregarFila(formulario, "Tipo de partido", comboTipo);
        agregarFila(formulario, "Goles para ganar", comboObjetivo);
        agregarFila(formulario, "Pais jugador 1", comboPais1);
        agregarFila(formulario, "Pais jugador 2 / maquina", comboPais2);

        JButton iniciar = new JButton("Iniciar");
        JButton volver = new JButton("Volver");
        iniciar.addActionListener(e -> iniciar(ventana));
        volver.addActionListener(e -> ventana.mostrarMenu());
        JPanel botones = new JPanel(new GridLayout(1, 2, 10, 0));
        botones.setOpaque(false);
        botones.add(volver);
        botones.add(iniciar);

        JLabel controles = new JLabel("<html><center>J1: A/D mover, W saltar, S patear, Q poder<br>"
                + "J2: flechas izq/der, ↑ saltar, ↓ patear, Ctrl derecho poder<br>"
                + "P pausa, Esc menu</center></html>", SwingConstants.CENTER);
        controles.setForeground(Color.WHITE);

        JPanel caja = new JPanel(new BorderLayout(0, 20));
        caja.setOpaque(false);
        caja.add(titulo, BorderLayout.NORTH);
        caja.add(formulario, BorderLayout.CENTER);
        JPanel sur = new JPanel(new GridLayout(0, 1, 0, 15));
        sur.setOpaque(false);
        sur.add(botones);
        sur.add(controles);
        caja.add(sur, BorderLayout.SOUTH);
        add(caja);
    }

    private void agregarFila(JPanel formulario, String texto, JComponent componente){
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(Color.WHITE);
        formulario.add(etiqueta);
        formulario.add(componente);
    }

    private void iniciar(DOPOSoccerGUI ventana){
        Modalidad modalidad = Modalidad.values()[comboModalidad.getSelectedIndex()];
        TipoPartido tipo = TipoPartido.values()[comboTipo.getSelectedIndex()];
        int objetivo = Integer.parseInt((String) comboObjetivo.getSelectedItem());
        Pais pais1 = (Pais) comboPais1.getSelectedItem();
        Pais pais2 = (Pais) comboPais2.getSelectedItem();
        ventana.iniciarJuego(modalidad, tipo, objetivo, pais1, pais2);
    }
}
